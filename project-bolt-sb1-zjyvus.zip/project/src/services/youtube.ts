import axios from 'axios';
import { YouTubeVideo, YouTubeApiResponse } from '../types/youtube';
import { YOUTUBE_API_KEY, PLAYLIST_IDS, CACHE_DURATION } from '../config/constants';
import { Cache } from './cache';

const videoCache = new Cache<YouTubeVideo[]>(CACHE_DURATION);

const fetchVideos = async (playlistId: string): Promise<YouTubeVideo[]> => {
  const cacheKey = `playlist_${playlistId}`;
  const cachedVideos = videoCache.get(cacheKey);
  
  if (cachedVideos) {
    return cachedVideos;
  }

  try {
    const response = await axios.get<YouTubeApiResponse>(
      `https://www.googleapis.com/youtube/v3/playlistItems`,
      {
        params: {
          part: 'snippet',
          playlistId,
          maxResults: 50,
          key: YOUTUBE_API_KEY,
        },
      }
    );

    const videos = response.data.items.map(item => ({
      id: item.id,
      title: item.snippet.title,
      description: item.snippet.description,
      thumbnail: item.snippet.thumbnails.high.url,
      snippet: {
        resourceId: {
          videoId: item.snippet.resourceId.videoId
        }
      }
    }));

    videoCache.set(cacheKey, videos);
    return videos;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(`Failed to fetch videos: ${error.message}`);
    }
    throw new Error('An unexpected error occurred while fetching videos');
  }
};

export const fetchPlaylistVideos = () => fetchVideos(PLAYLIST_IDS.main);
export const fetchAdventCalendarVideos = () => fetchVideos(PLAYLIST_IDS.advent);