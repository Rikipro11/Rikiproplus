import { useState, useEffect } from 'react';
import { YouTubeVideo } from '../types/youtube';
import { fetchPlaylistVideos, fetchAdventCalendarVideos } from '../services/youtube';

export const useVideos = (type?: 'main' | 'advent' | 'all') => {
  const [videos, setVideos] = useState<YouTubeVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadVideos = async () => {
      try {
        if (type === 'main') {
          const mainVideos = await fetchPlaylistVideos();
          setVideos(mainVideos);
        } else if (type === 'advent') {
          const adventVideos = await fetchAdventCalendarVideos();
          setVideos(adventVideos);
        } else {
          const [mainVideos, adventVideos] = await Promise.all([
            fetchPlaylistVideos(),
            fetchAdventCalendarVideos()
          ]);
          setVideos([...mainVideos, ...adventVideos]);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load videos');
      } finally {
        setLoading(false);
      }
    };

    loadVideos();
  }, [type]);

  return { videos, loading, error };
};