export interface YouTubeVideo {
  id: string;
  title: string;
  thumbnail: string;
  description: string;
  snippet: {
    resourceId: {
      videoId: string;
    };
  };
}

export interface YouTubeApiResponse {
  items: Array<{
    id: string;
    snippet: {
      title: string;
      description: string;
      thumbnails: {
        high: {
          url: string;
        };
      };
      resourceId: {
        videoId: string;
      };
    };
  }>;
}