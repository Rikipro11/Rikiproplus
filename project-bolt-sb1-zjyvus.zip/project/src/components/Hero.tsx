import React, { useState, useEffect } from 'react';
import { Play, Info } from 'lucide-react';
import { fetchPlaylistVideos } from '../services/youtube';
import { YouTubeVideo } from '../types/youtube';
import VideoModal from './VideoModal';

const Hero = () => {
  const [videos, setVideos] = useState<YouTubeVideo[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [isChanging, setIsChanging] = useState(false);

  useEffect(() => {
    const loadVideos = async () => {
      try {
        const fetchedVideos = await fetchPlaylistVideos();
        setVideos(fetchedVideos);
      } catch (error) {
        console.error('Error loading videos:', error);
      } finally {
        setLoading(false);
      }
    };

    loadVideos();
  }, []);

  useEffect(() => {
    if (videos.length === 0) return;

    const interval = setInterval(() => {
      setIsChanging(true);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % videos.length);
        setIsChanging(false);
      }, 300);
    }, 10000);

    return () => clearInterval(interval);
  }, [videos.length]);

  if (loading || videos.length === 0) {
    return (
      <div className="relative h-[90vh] w-full bg-gray-900 animate-pulse">
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent" />
      </div>
    );
  }

  const currentVideo = videos[currentIndex];

  return (
    <div className="relative h-[90vh] w-full overflow-hidden">
      <div className={`absolute inset-0 transition-transform duration-300 ease-out ${isChanging ? 'scale-105' : 'scale-100'}`}>
        <img
          src={currentVideo.thumbnail}
          alt={currentVideo.title}
          className={`w-full h-full object-cover transition-opacity duration-300 ${isChanging ? 'opacity-80' : 'opacity-100'}`}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent" />
      </div>
      
      <div className="relative h-full container mx-auto px-4 flex items-center">
        <div className={`max-w-2xl space-y-4 transition-all duration-500 ${isChanging ? 'opacity-0 translate-x-10' : 'opacity-100 translate-x-0'}`}>
          <h1 className="text-5xl md:text-7xl font-bold animate-fade-in">{currentVideo.title}</h1>
          <p className="text-lg text-gray-200">{currentVideo.description}</p>
          <div className="flex space-x-4">
            <button 
              onClick={() => setSelectedVideoId(currentVideo.snippet.resourceId.videoId)}
              className="flex items-center px-8 py-3 bg-cyan-500 text-white rounded hover:bg-cyan-600 transition-all duration-300 hover:scale-105 active:scale-95"
            >
              <Play className="mr-2 transition-transform group-hover:scale-110" size={24} />
              Play
            </button>
            <button className="flex items-center px-8 py-3 bg-gray-500/70 text-white rounded hover:bg-gray-500/50 transition-all duration-300 hover:scale-105 active:scale-95">
              <Info className="mr-2 transition-transform group-hover:scale-110" size={24} />
              More Info
            </button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {videos.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setIsChanging(true);
              setTimeout(() => {
                setCurrentIndex(index);
                setIsChanging(false);
              }, 300);
            }}
            className={`w-2 h-2 rounded-full transition-all duration-300 transform hover:scale-125 ${
              index === currentIndex 
                ? 'bg-cyan-500 w-4' 
                : 'bg-gray-400 hover:bg-gray-300'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {selectedVideoId && (
        <VideoModal
          videoId={selectedVideoId}
          onClose={() => setSelectedVideoId(null)}
        />
      )}
    </div>
  );
};

export default Hero;