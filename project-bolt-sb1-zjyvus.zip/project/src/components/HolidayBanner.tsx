import React from 'react';
import { Snowflake, Gift } from 'lucide-react';

const HolidayBanner = () => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-r from-red-600 to-green-600 rounded-lg p-6 text-white shadow-lg">
      <div className="absolute top-0 left-0 w-full h-full">
        <Snowflake className="absolute animate-bounce text-white/20" style={{ top: '10%', left: '10%' }} />
        <Snowflake className="absolute animate-bounce delay-100 text-white/20" style={{ top: '30%', left: '80%' }} />
        <Snowflake className="absolute animate-bounce delay-200 text-white/20" style={{ top: '70%', left: '20%' }} />
        <Gift className="absolute animate-bounce delay-300 text-white/20" style={{ top: '50%', left: '90%' }} />
      </div>
      
      <div className="relative flex items-center justify-center text-center">
        <h2 className="text-3xl md:text-4xl font-bold">
          Merry Christmas and Happy Holidays! 🎅 🎄 🎁
        </h2>
      </div>
    </div>
  );
};

export default HolidayBanner;