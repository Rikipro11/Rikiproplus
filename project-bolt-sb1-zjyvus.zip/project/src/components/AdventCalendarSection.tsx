import React, { useState } from 'react';
import { Calendar } from 'lucide-react';
import MovieCard from './MovieCard';
import VideoModal from './VideoModal';
import { useVideos } from '../hooks/useVideos';

const AdventCalendarSection = () => {
  const { videos, loading, error } = useVideos('advent');
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);

  const handlePlay = (videoId: string) => {
    setSelectedVideoId(videoId);
  };

  if (loading) {
    return (
      <section className="mb-8">
        <h2 className="flex items-center text-2xl font-bold mb-4">
          <Calendar className="mr-2" /> XMAS Advent Calendar
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {[...Array(24)].map((_, index) => (
            <div key={index} className="aspect-square bg-gray-800 animate-pulse rounded-md" />
          ))}
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="mb-8">
        <h2 className="flex items-center text-2xl font-bold mb-4">
          <Calendar className="mr-2" /> XMAS Advent Calendar
        </h2>
        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-md">
          <p className="text-red-400">{error}</p>
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <h2 className="flex items-center text-2xl font-bold mb-4">
        <Calendar className="mr-2" /> XMAS Advent Calendar
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {videos.map((video, index) => (
          <div key={video.id} className="relative group">
            <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-green-500/20 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <div className="absolute top-2 left-2 w-8 h-8 flex items-center justify-center bg-red-500 text-white rounded-full font-bold">
              {index + 1}
            </div>
            <MovieCard video={video} onPlay={handlePlay} />
          </div>
        ))}
      </div>
      {selectedVideoId && (
        <VideoModal
          videoId={selectedVideoId}
          onClose={() => setSelectedVideoId(null)}
        />
      )}
    </section>
  );
};

export default AdventCalendarSection;