import React, { useState, useEffect } from 'react';
import { Play, Info } from 'lucide-react';
import { YouTubeVideo } from '../types/youtube';
import { fetchPlaylistVideos } from '../services/youtube';
import VideoModal from './VideoModal';

const DynamicHero = () => {
  const [featuredVideo, setFeaturedVideo] = useState<YouTubeVideo | null>(null);
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);

  useEffect(() => {
    const loadFeaturedVideo = async () => {
      const videos = await fetchPlaylistVideos();
      if (videos.length > 0) {
        setFeaturedVideo(videos[0]);
      }
    };

    loadFeaturedVideo();
  }, []);

  if (!featuredVideo) {
    return (
      <div className="relative h-[90vh] w-full bg-gray-900 animate-pulse" />
    );
  }

  return (
    <>
      <div className="relative h-[90vh] w-full">
        <div className="absolute inset-0">
          <img
            src={featuredVideo.thumbnail}
            alt={featuredVideo.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent" />
        </div>
        
        <div className="relative h-full container mx-auto px-4 flex items-center">
          <div className="max-w-2xl space-y-4">
            <h1 className="text-5xl md:text-7xl font-bold">{featuredVideo.title}</h1>
            <p className="text-lg text-gray-200">
              {featuredVideo.description}
            </p>
            <div className="flex space-x-4">
              <button 
                onClick={() => setSelectedVideoId(featuredVideo.snippet.resourceId.videoId)}
                className="flex items-center px-8 py-3 bg-cyan-500 text-white rounded hover:bg-cyan-600 transition font-semibold"
              >
                <Play className="mr-2" size={24} />
                Play
              </button>
              <button className="flex items-center px-8 py-3 bg-gray-500/70 text-white rounded hover:bg-gray-500/50 transition font-semibold">
                <Info className="mr-2" size={24} />
                More Info
              </button>
            </div>
          </div>
        </div>
      </div>
      {selectedVideoId && (
        <VideoModal
          videoId={selectedVideoId}
          onClose={() => setSelectedVideoId(null)}
        />
      )}
    </>
  );
};

export default DynamicHero;