import React from 'react';
import { Play } from 'lucide-react';
import { YouTubeVideo } from '../types/youtube';

interface MovieCardProps {
  video: YouTubeVideo;
  onPlay?: (videoId: string) => void;
}

const MovieCard: React.FC<MovieCardProps> = ({ video, onPlay }) => {
  return (
    <div className="relative group cursor-pointer">
      <div className="aspect-video bg-gray-800 rounded-md overflow-hidden transition-all duration-300 transform group-hover:scale-105 group-hover:shadow-xl group-hover:shadow-cyan-500/10">
        <img
          src={video.thumbnail}
          alt={video.title}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-end p-4 rounded-md">
        <div className="w-full transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
          <h3 className="text-sm font-semibold mb-2 line-clamp-2">{video.title}</h3>
          <button 
            type="button"
            aria-label={`Play ${video.title}`}
            onClick={() => onPlay?.(video.snippet.resourceId.videoId)}
            className="w-full flex items-center justify-center bg-cyan-500/20 backdrop-blur-sm text-white text-sm py-1 rounded-md hover:bg-cyan-500/30 transition-all duration-300 hover:scale-105 active:scale-95"
          >
            <Play size={16} className="mr-1 transition-transform group-hover:scale-110" />
            Play
          </button>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;