import React, { useEffect, useState } from 'react';
import { Grid } from 'lucide-react';
import MovieCard from './MovieCard';
import VideoModal from './VideoModal';
import { YouTubeVideo } from '../types/youtube';
import { fetchPlaylistVideos } from '../services/youtube';

const AllVideosSection = () => {
  const [videos, setVideos] = useState<YouTubeVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadVideos = async () => {
      try {
        const fetchedVideos = await fetchPlaylistVideos();
        setVideos(fetchedVideos);
      } catch (err) {
        setError('Failed to load videos. Please try again later.');
        console.error('Error loading videos:', err);
      } finally {
        setLoading(false);
      }
    };

    loadVideos();
  }, []);

  const handlePlay = (videoId: string) => {
    setSelectedVideoId(videoId);
  };

  if (loading) {
    return (
      <section className="mb-8">
        <h2 className="flex items-center text-2xl font-bold mb-4">
          <Grid className="mr-2" /> All Videos
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {[...Array(10)].map((_, index) => (
            <div key={index} className="aspect-video bg-gray-800 animate-pulse rounded-md" />
          ))}
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="mb-8">
        <h2 className="flex items-center text-2xl font-bold mb-4">
          <Grid className="mr-2" /> All Videos
        </h2>
        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-md">
          <p className="text-red-400">{error}</p>
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <h2 className="flex items-center text-2xl font-bold mb-4">
        <Grid className="mr-2" /> All Videos
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {videos.map((video) => (
          <MovieCard key={video.id} video={video} onPlay={handlePlay} />
        ))}
      </div>
      {selectedVideoId && (
        <VideoModal
          videoId={selectedVideoId}
          onClose={() => setSelectedVideoId(null)}
        />
      )}
    </section>
  );
};

export default AllVideosSection;