import React, { useState, useEffect, useRef } from 'react';
import { Search, Bell, Zap, X } from 'lucide-react';
import VideoModal from './VideoModal';
import { useVideos } from '../hooks/useVideos';

interface Notification {
  id: string;
  title: string;
  date: Date;
  read: boolean;
}

const Navbar = () => {
  const { videos, loading } = useVideos('all');
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);
  const searchRef = useRef<HTMLDivElement>(null);
  const notificationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setSearchOpen(false);
      }
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredVideos = searchQuery
    ? videos.filter(video =>
        video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        video.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const handleSearchClick = () => {
    setSearchOpen(true);
    setShowNotifications(false);
  };

  const handleNotificationClick = () => {
    setShowNotifications(prev => !prev);
    setSearchOpen(false);
  };

  const handleVideoSelect = (videoId: string) => {
    setSelectedVideoId(videoId);
    setSearchOpen(false);
    setSearchQuery('');
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <nav className="fixed w-full z-50 bg-gradient-to-b from-black/70 to-transparent">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          <div className="flex items-center space-x-8">
            <div className="flex items-center text-cyan-500 text-3xl font-bold tracking-wider">
              <Zap className="mr-2" size={32} />
              RIKIPRO+
            </div>
            <div className="hidden md:flex space-x-6">
              <button className="text-sm font-medium hover:text-cyan-400 transition-colors">Home</button>
              <button className="text-sm font-medium hover:text-cyan-400 transition-colors">TV Shows</button>
              <button className="text-sm font-medium hover:text-cyan-400 transition-colors">Movies</button>
              <button className="text-sm font-medium hover:text-cyan-400 transition-colors">New & Popular</button>
              <button className="text-sm font-medium hover:text-cyan-400 transition-colors">My List</button>
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <div ref={searchRef} className="relative">
              {searchOpen ? (
                <div className="absolute right-0 top-0 w-96 bg-[#141414] border border-gray-700 rounded-md overflow-hidden shadow-lg">
                  <div className="flex items-center p-2 border-b border-gray-700">
                    <Search size={20} className="text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search videos..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-transparent border-none focus:outline-none px-2 text-white"
                      autoFocus
                    />
                    <button
                      onClick={() => {
                        setSearchOpen(false);
                        setSearchQuery('');
                      }}
                      className="text-gray-400 hover:text-white"
                    >
                      <X size={20} />
                    </button>
                  </div>
                  {loading ? (
                    <div className="p-4 text-center text-gray-400">Loading...</div>
                  ) : filteredVideos.length > 0 ? (
                    <div className="max-h-[70vh] overflow-y-auto">
                      {filteredVideos.map(video => (
                        <div
                          key={video.id}
                          className="p-4 hover:bg-gray-800 cursor-pointer flex items-center space-x-3"
                          onClick={() => handleVideoSelect(video.snippet.resourceId.videoId)}
                        >
                          <img 
                            src={video.thumbnail} 
                            alt={video.title}
                            className="w-24 h-16 object-cover rounded"
                          />
                          <div>
                            <p className="text-sm text-white font-medium line-clamp-2">{video.title}</p>
                            <p className="text-xs text-gray-400 mt-1 line-clamp-1">{video.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : searchQuery ? (
                    <div className="p-4 text-center text-gray-400">No videos found</div>
                  ) : null}
                </div>
              ) : (
                <button
                  onClick={handleSearchClick}
                  className="hover:text-cyan-400 transition-colors"
                  aria-label="Search"
                >
                  <Search size={20} />
                </button>
              )}
            </div>
            
            <div ref={notificationRef} className="relative">
              <button
                onClick={handleNotificationClick}
                className="hover:text-cyan-400 transition-colors relative"
                aria-label="Notifications"
              >
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-cyan-500 w-3 h-3 rounded-full" />
                )}
              </button>
              
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-[#141414] border border-gray-700 rounded-md shadow-lg overflow-hidden">
                  <div className="p-3 border-b border-gray-700">
                    <h3 className="text-lg font-semibold">Notifications</h3>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {notifications.length > 0 ? (
                      notifications.map(notification => (
                        <div
                          key={notification.id}
                          className={`p-3 border-b border-gray-700 hover:bg-gray-800 cursor-pointer ${
                            !notification.read ? 'bg-gray-900' : ''
                          }`}
                          onClick={() => markNotificationAsRead(notification.id)}
                        >
                          <p className="text-sm font-medium">{notification.title}</p>
                          <p className="text-xs text-gray-400 mt-1">
                            {notification.date.toLocaleDateString()}
                          </p>
                        </div>
                      ))
                    ) : (
                      <div className="p-3 text-center text-gray-400">
                        No new notifications
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      {selectedVideoId && (
        <VideoModal
          videoId={selectedVideoId}
          onClose={() => setSelectedVideoId(null)}
        />
      )}
    </nav>
  );
};

export default Navbar;