export const YOUTUBE_API_KEY = 'AIzaSyBhsMxdiM4dtSkTjS03yh49o8dLaecEebs';

export const PLAYLIST_IDS = {
  main: 'PLt2fQvWSwJxskn2YLPWs9hW6z89p_mpfZ',
  advent: 'PLt2fQvWSwJxvgp5hJjIcRU4qgWsC6guy8'
} as const;

export const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes