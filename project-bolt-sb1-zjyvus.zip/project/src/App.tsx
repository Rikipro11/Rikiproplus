import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import HolidayBanner from './components/HolidayBanner';
import AllVideosSection from './components/AllVideosSection';

function App() {
  return (
    <div className="min-h-screen bg-[#141414] text-white">
      <Navbar />
      <main>
        <Hero />
        <div className="container mx-auto px-4 space-y-8 py-8">
          <HolidayBanner />
          <AllVideosSection />
        </div>
      </main>
    </div>
  );
}

export default App;